import time
import nltk
import streamlit as st
import speech_recognition as sr
import wikipedia
import random

# Download necessary NLTK data
nltk.download('punkt')

# Function to fetch a random sentence from Wikipedia
def get_random_sentence():
    while True:
        try:
            random_title = wikipedia.random()
            summary = wikipedia.summary(random_title, sentences=5)
            sentences = nltk.tokenize.sent_tokenize(summary)
            return random.choice(sentences)
        except Exception:
            continue  # Try again if an error occurs

# Function to calculate speaking time (max 15 sec)
def calculate_speaking_time(sentence):
    words = nltk.word_tokenize(sentence)
    avg_read_speed = 3  # Words per second
    return min(len(words) / avg_read_speed, 15)

# Function to recognize speech from the microphone
def recognize_speech(timeout_duration):
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        st.info("🎤 Speak now... (Listening for {} seconds)".format(timeout_duration))
        try:
            audio = recognizer.listen(source, timeout=timeout_duration)
            text = recognizer.recognize_google(audio)
            return text
        except sr.UnknownValueError:
            return "❌ Error: Could not understand speech."
        except sr.RequestError:
            return "⚠️ Error: Speech recognition service unavailable."

# Main function for speaking practice with auto-enabled speaking button
def run_speaking_practice(num_sentences):
    for i in range(num_sentences):
        sentence = get_random_sentence()
        allowed_time = calculate_speaking_time(sentence)

        st.write(f"**Sentence {i+1}:** {sentence}")
        st.write(f"⏳ You have {round(allowed_time, 2)} seconds to read this.")
        
        time.sleep(2)  # Brief pause before auto-enabling speech recognition

        user_speech = recognize_speech(allowed_time)  # Auto-enable speech capture
        st.write(f"✅ **You said:** {user_speech}")

        # Calculate accuracy
        correct_words = set(nltk.word_tokenize(sentence.lower()))
        spoken_words = set(nltk.word_tokenize(user_speech.lower()))
        accuracy = (len(correct_words & spoken_words) / len(correct_words)) * 100

        # Speed Analysis
        time_taken = len(spoken_words) / 3  # Approximate time taken
        speed = len(spoken_words) / time_taken  # Words per second
        normal_speed = len(correct_words) / allowed_time  # Ideal words per second

        if speed > normal_speed * 1.3:
            st.write("⚠️ You are speaking too fast! Try to slow down.")
        elif speed < normal_speed * 0.7:
            st.write("⚠️ You are speaking too slowly! Try to speak more fluently.")
        else:
            st.write("✅ Your speaking speed is balanced.")

        # Extra time analysis
        extra_time = time_taken - allowed_time
        if extra_time > 0:
            st.write(f"⏳ You took {round(extra_time, 2)} seconds extra.")

        st.write(f"🎯 Accuracy: {round(accuracy, 2)}%")
        st.write("---")

# Streamlit app interface
st.title("🎤 English Speaking Practice App")
st.write("Improve your speaking skills by reading sentences aloud and receiving feedback.")

num_sentences = st.number_input("Enter the number of sentences to practice (Max 50):", min_value=1, max_value=50, value=5)

if st.button("Start Practice"):
    run_speaking_practice(num_sentences)
